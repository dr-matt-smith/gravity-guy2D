﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {
	public GameObject shieldGO;
	public AudioClip yumSound;
	public AudioClip dieSound;

	private float delayBetweenDeaths = 5f;
	private float nextTimeAllowedToDie = 0;

	private PlayerDisplay playerDisplay;

	private int lives = 3;
	private int score = 0;
	private float deathY = -15;

	//-----------------------------
	void Start()
	{
		playerDisplay = GetComponent<PlayerDisplay>();
		playerDisplay.UpdateScoreText(score);
		playerDisplay.UpdateLivesImage(lives);
	}
	
	//-----------------------------
	void Update()
	{
		CheckGameWon();
		CheckDeathYReached();
		DisplayShieldIfCannotDie();
	}

	//---------------------------------
	private void DisplayShieldIfCannotDie()
	{
		bool cannotDie = (Time.time <= nextTimeAllowedToDie);
		// show shield if cannot die
		// else hide it
		shieldGO.SetActive( cannotDie );
	}

	//-----------------------------
	private void CheckDeathYReached()
	{
		float y = transform.position.y;
		if(y < deathY){
			LoseLife();
		}
	}

	//-----------------------------
	private void LoseLife()
	{
		if(Time.time > nextTimeAllowedToDie){
			lives--;

			// update our next time allowed to die for a future time ...
			nextTimeAllowedToDie = Time.time + delayBetweenDeaths;
		}

		if(lives < 0)
		{
			Application.LoadLevel("scene1_GameOver");
		}
		
		playerDisplay.UpdateLivesImage(lives);
		MoveToStartPosition();
		audio.PlayOneShot(dieSound);
	}

	//-----------------------------
	private void MoveToStartPosition()
	{
		GameObject respawnGO = ChooseRandomObjectWithTag("Respawn");
		Vector3 startPosition = respawnGO.transform.position;
		transform.position = startPosition;

		// remove all horizontal/vertical movement when respawned
		rigidbody2D.velocity = Vector2.zero;
	}

	//-----------------------------
	private GameObject ChooseRandomObjectWithTag(string tag)
	{
		GameObject[] taggedObjects = GameObject.FindGameObjectsWithTag(tag);
		int numTaggedObjects = taggedObjects.Length;
		int randomIndex = Random.Range(0, numTaggedObjects);
		return taggedObjects[randomIndex];
	}

	//-----------------------------
	void OnTriggerEnter2D(Collider2D hit)
	{
		if(hit.CompareTag("Food"))
		{
			score++;
			playerDisplay.UpdateScoreText(score);
			Destroy (hit.gameObject);
			audio.PlayOneShot(yumSound);
		}

		if(hit.CompareTag("Spikes"))
		{
			LoseLife();
		}
	}

	//------------------------------
	private int CountObjectsWithTag(string tag)
	{
		GameObject[] foodObjects = GameObject.FindGameObjectsWithTag(tag);
		return foodObjects.Length;
	}

	//-------------------------------
	private void CheckGameWon()
	{
		print ("hello");

		int numFoodObjects = CountObjectsWithTag("Food");
		print ("number of food objects left = " + numFoodObjects);
		
		if(numFoodObjects < 1)
		{
			Application.LoadLevel("scene3_GameWon");
		}
	}

}
