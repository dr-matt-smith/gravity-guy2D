﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {
	public AudioClip yumSound;
	public AudioClip dieSound;

	private PlayerDisplay playerDisplay;

	private int lives = 3;
	private int score = 0;
	private float deathY = -15;

	//-----------------------------
	void Start(){
		playerDisplay = GetComponent<PlayerDisplay>();
		playerDisplay.UpdateScoreText(score);
		playerDisplay.UpdateLivesText(lives);
	}
	
	//-----------------------------
	void Update(){
		float y = transform.position.y;
		if(y < deathY){
			LoseLife();
		}
	}

	//-----------------------------
	private void LoseLife(){
		lives--;

		if(lives < 0){
			Application.LoadLevel("scene1_GameOver");
		}

		playerDisplay.UpdateLivesText(lives);
		MoveToStartPosition();
		audio.PlayOneShot(dieSound);
	}

	//-----------------------------
	private void MoveToStartPosition(){
		Vector3 startPosition = new Vector3(0,5,0);
		transform.position = startPosition;
	}

	//-----------------------------
	void OnTriggerEnter2D(Collider2D hit){
		if(hit.CompareTag("Food")){
			score++;
			playerDisplay.UpdateScoreText(score);
			Destroy (hit.gameObject);
			audio.PlayOneShot(yumSound);
		}

		if(hit.CompareTag("Spikes")){
			LoseLife();
		}
	}
}
