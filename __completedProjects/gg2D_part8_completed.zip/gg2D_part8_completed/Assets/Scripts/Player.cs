﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {
	public AudioClip yumSound;
	public AudioClip dieSound;

	private PlayerDisplay playerDisplay;

	private int lives = 3;
	private int score = 0;
	private float deathY = -15;

	//-----------------------------
	void Start()
	{
		playerDisplay = GetComponent<PlayerDisplay>();
		playerDisplay.UpdateScoreText(score);
		playerDisplay.UpdateLivesImage(lives);
	}
	
	//-----------------------------
	void Update()
	{
		CheckGameWon();
		CheckDeathYReached();
	}

	//-----------------------------
	private void CheckDeathYReached()
	{
		float y = transform.position.y;
		if(y < deathY){
			LoseLife();
		}
	}

	//-----------------------------
	private void LoseLife()
	{
		lives--;

		if(lives < 0)
		{
			Application.LoadLevel("scene1_GameOver");
		}

		playerDisplay.UpdateLivesImage(lives);
		MoveToStartPosition();
		audio.PlayOneShot(dieSound);
	}

	//-----------------------------
	private void MoveToStartPosition()
	{
		GameObject respawnGO = ChooseRandomObjectWithTag("Respawn");
		Vector3 startPosition = respawnGO.transform.position;
		transform.position = startPosition;

		// remove all horizontal/vertical movement when respawned
		rigidbody2D.velocity = Vector2.zero;
	}

	//-----------------------------
	private GameObject ChooseRandomObjectWithTag(string tag)
	{
		GameObject[] taggedObjects = GameObject.FindGameObjectsWithTag(tag);
		int numTaggedObjects = taggedObjects.Length;
		int randomIndex = Random.Range(0, numTaggedObjects);
		return taggedObjects[randomIndex];
	}

	//-----------------------------
	void OnTriggerEnter2D(Collider2D hit)
	{
		if(hit.CompareTag("Food"))
		{
			score++;
			playerDisplay.UpdateScoreText(score);
			Destroy (hit.gameObject);
			audio.PlayOneShot(yumSound);
		}

		if(hit.CompareTag("Spikes"))
		{
			LoseLife();
		}
	}

	//------------------------------
	private int CountObjectsWithTag(string tag)
	{
		GameObject[] foodObjects = GameObject.FindGameObjectsWithTag(tag);
		return foodObjects.Length;
	}

	//-------------------------------
	private void CheckGameWon()
	{
		print ("hello");

		int numFoodObjects = CountObjectsWithTag("Food");
		print ("number of food objects left = " + numFoodObjects);
		
		if(numFoodObjects < 1)
		{
			Application.LoadLevel("scene3_GameWon");
		}
	}

}
