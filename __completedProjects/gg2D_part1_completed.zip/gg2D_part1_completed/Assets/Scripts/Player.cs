﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

	private int score = 0;
	
	void Update(){
		string scoreMessage = "Score = " + score;
		print(scoreMessage);
	}

	void OnTriggerEnter2D(Collider2D hit){
		if(hit.CompareTag("Food")){
			score++;
			Destroy (hit.gameObject);
		}
	}
}
