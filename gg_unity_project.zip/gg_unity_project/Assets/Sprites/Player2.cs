﻿using UnityEngine;
using System.Collections;

public class Player2 : MonoBehaviour {
	//
	// public links
	//
	public GUIText scoreTextWhite;
	public GUIText scoreTextRed;

	//
	// GUI
	//
	private void OnGUI(){
		DisplayScore();
	}

	private void DisplayScore(){
		string scoreMessage = "Score: " + score;
		//		GUILayout.Label(livesMessage);
		scoreTextRed.text = scoreMessage;
		scoreTextWhite.text = scoreMessage;
	}

	//
	// properties
	//
	private int lives = 0;
	private int score = 0;

	//
	// spawn
	//
	private void RestartPlayer(){
		Vector3 startPosition = new Vector3(0,0,0);
		transform.position = startPosition;
	}

	//
	// LOGIC - collisons ..
	//
	private void OnTriggerEnter2D(Collider2D hit){
		string tag = hit.tag;

		if( "Spikes" == tag){
			HitSpikes();
		}

		if( "Food" == tag){
			HitFood();
		}
	}

	private void HitSpikes(){
		LoseLife ();
	}

	private void HitFood(){
		score++;
	}

	private void LoseLife(){
		print ("AAAAAARTRGGGGGG");
		RestartPlayer();
		lives--;
	}

}
